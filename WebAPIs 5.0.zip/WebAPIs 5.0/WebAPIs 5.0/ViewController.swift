//
//  ViewController.swift
//  WebAPIs
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Post Method with Row Json
//        self.callPostAPI()
        
        //Get Method
        self.callGetAPI()
        
        //Image Downloading
//        callImageDownloading()
        
        //File/image Uploading
//        APIManager.shared.uploadingImage() //currently we dont have any server detail to upload data
    }

    func callImageDownloading(){
        APIManager.shared.downlodingImage { (img: UIImage) in
            print("img:::: \(img)")
            self.imgView.image = img
        }
    }
    
    func callPostAPI(){
        APIManager.shared.postMethod(param: ["foo1":"bar1", "foo2":"bar2"], paramFormate: Formate.formData, successful: { (objRootClass: RootClass) in
            print("POST URL is ::: \(String(describing: objRootClass.url))")
            do {
                //Save object
                UserDefaults.standard.set(try? PropertyListEncoder().encode(objRootClass), forKey:"RootClass")
                UserDefaults.standard.synchronize()
                
                //Retrive object
                if let data = UserDefaults.standard.value(forKey:"RootClass") as? Data {
                    if let rootClass = try? PropertyListDecoder().decode(RootClass.self, from: data){
                        print("root Class::: \(rootClass)")
                    }
                }
            }
        }) { (err: APIError) in
            print("error::: \(err.localizedDescription)")
        }
    }
    
    func callGetAPI(){
        APIManager.shared.getMethod(successful: { (objRootClass: RootClass) in
            print("GET URL is:::: \(String(describing: objRootClass.headers))")
//            print("GET URL is:::: \(String(describing: objRootClass.toDictionary()))")
        }) { (err: APIError) in
            print("error::: \(err.localizedDescription)")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
}

