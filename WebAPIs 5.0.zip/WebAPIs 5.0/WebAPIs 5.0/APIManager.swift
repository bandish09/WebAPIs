//
//  APIManager.swift
//  WebAPIs
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import ObjectMapper
import AlamofireObjectMapper


//Best way to learn:::   https://codewithchris.com/alamofire/


enum Formate {
    case rowjson
    case formData
}

let BaseUrl = "https://postman-echo.com/"




class APIManager {
    static let shared = APIManager()
    let NetworkSharedManager = NetworkReachability.sharedManager

    let getUrl: String = "\(BaseUrl)\("get?foo1=bar1&foo2=bar2")"
    let postUrl: String = "\(BaseUrl)\("post")"
    
    func getHeader() -> HTTPHeaders {
        var headerParam: HTTPHeaders = [:]
        headerParam["Authorization"] = "Bearer yourToken"
        headerParam["Accept"] = "application/json"
        return headerParam
    }
    
    func getMethod(successful:@escaping (RootClass)->Void, failure:@escaping (APIError)->Void){
        
        
        
//        print(self.NetworkSharedManager.isNetworkReachable)
        
        
        //Check if Internet is available or not.
        print(self.NetworkSharedManager.reachability.isReachable)
        

        /*
        AF.request(getUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil, interceptor: nil).responseJSON { response in
            debugPrint("Response: \(response)")
            if let json = response.value{
                let objRootClass = RootClass(fromDictionary: json as! [String : Any])
                successful(objRootClass)
            } else{
                if let err = response.error{
                    let api = APIError()
                    api.error = err
                    failure(api)
                } else{
                    print("something went wrong")
                }
            }
            
        }*/
        
        
        AF.request(getUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil, interceptor: nil).responseDecodable(of: RootClass.self) { (response) in
            
            debugPrint("Response: \(response)")
            if let data = response.value{
                successful(data)
            } else{
                if let err = response.error{
                    let api = APIError()
                    api.error = err
                    failure(api)
                } else{
                    print("something went wrong")
                }
            }
        }
        
        
        
        /*AF.request("https://httpbin.org/get", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil, interceptor: nil).responseDecodable(of: HTTPBinResponse.self) { (response) in
            debugPrint("Response: \(response)")
        }*/
        
        /*
        AF.request("https://httpbin.org/get").responseDecodable(of: HTTPBinResponse.self) { response in
            debugPrint("Response: \(response)")
        }*/
        
        /*
        AF.request("https://httpbin.org/get").response { response in
            debugPrint(response)
        }*/
        
        
        /*
        AF.request(getUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil, interceptor: nil).responseString { (response) in
            print("response::: \(response)")
        }*/
        
        
    }

    
    
    func postMethod(param:[String:Any], paramFormate: Formate, successful:@escaping (RootClass)->Void, failure:@escaping (APIError)->Void){

//Note::  1. if encoding formate is 'JsonEncoding.defaul' then parameter is passed with Row json formate
//        2. if encoding formate is 'URLEncoding.default' then parameter is passed with form-data formate
        
        
        var encodingFormat: ParameterEncoding?
        if paramFormate == .rowjson{
            encodingFormat = JSONEncoding.default //JsonEncoding.defalt is formate so you will get param in 'data' key value.
        } else if paramFormate == .formData{
            encodingFormat = URLEncoding.default //URLEncoding.defalt is formate so you will get param in 'form' key value.
        }
        
//        Alamofire.request(postUrl, method: .post, parameters: param, encoding: encodingFormat!, headers: nil).responseString { (response: DataResponse<String>) in
//            print("response::: \(response)") //JsonEncoding.defalt is formate so you will get param in 'data' key value.
//        }
        
        AF.request(postUrl, method: .post, parameters: param, encoding: encodingFormat!, headers: nil, interceptor: nil).responseDecodable(of: RootClass.self) { (response) in
            debugPrint("Response: \(response)")
            if let data = response.value{
                successful(data)
            } else{
                if let err = response.error{
                    let api = APIError()
                    api.error = err
                    failure(api)
                } else{
                    print("something went wrong")
                }
            }
            
            
        }
    }

    
    func downlodingImage(imageBlock:@escaping (UIImage)->Void){

        let destination: DownloadRequest.Destination = { _, _ in
            let documentsURL = FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask)[0]
                let fileURL = documentsURL.appendingPathComponent("image.png")
                return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }
        
        AF.download("https://httpbin.org/image/png", to: destination).response { response in
            if response.error == nil, let imagePath = response.fileURL?.path {
                if let image = UIImage(contentsOfFile: imagePath){
                    imageBlock(image)
                }
            } else{
                print("Failed:: image downloading")
            }
        }
    }
  
    
    /*
    func uploadingImage(){
        let data = Data("data".utf8)

        AF.upload(data, to: "https://httpbin.org/post").responseJSON { response in
            debugPrint(response)
        }
        
        //Uploading file/image with multipartform data
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(Data("one".utf8), withName: "one")
            multipartFormData.append(Data("two".utf8), withName: "two")
        }, to: "https://httpbin.org/post")
            .responseJSON { response in
                debugPrint(response)
        }

        //Uploading using file path
        let fileURL = Bundle.main.url(forResource: "video", withExtension: "mp4")!
        AF.upload(fileURL, to: "https://httpbin.org/post").responseJSON { response in
            debugPrint(response)
        }
    }
       */
}
