//
//  NetworkReachability.swift
//  Fracaz
//
//  Created by Bandish on 21/04/18.
//  Copyright © 2018 Bandish. All rights reserved.
//
//

import UIKit

/*
 Check Network reachability.
 */

class NetworkReachability {
    static let sharedManager = NetworkReachability()
    
    let reachability = Reachability()!
    var isNetworkReachable = false
//    var isNetworkReachable: Bool {
//        get{
//            return self.reachability.isReachable
//        }
//        set{}
//    }

    init() {
        //declare this property where it won't go out of scope relative to your listener
        
        reachability.whenReachable = { reachability in
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
            self.isNetworkReachable = true
        }
        reachability.whenUnreachable = { reachability in
            print("Not reachable")
            self.isNetworkReachable = false
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }
}
