//
//	RootClass.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
import AlamofireObjectMapper
import ObjectMapper

public struct RootClass : Codable {

	var args : Arg!
	var headers : Header!
	var url : String!
    
    

    /**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		if let argsData = dictionary["args"] as? [String:Any]{
			args = Arg(fromDictionary: argsData)
		}
		if let headersData = dictionary["headers"] as? [String:Any]{
			headers = Header(fromDictionary: headersData)
		}
		url = dictionary["url"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if args != nil{
			dictionary["args"] = args.toDictionary()
		}
		if headers != nil{
			dictionary["headers"] = headers.toDictionary()
		}
		if url != nil{
			dictionary["url"] = url
		}
		return dictionary
	}

   

}
