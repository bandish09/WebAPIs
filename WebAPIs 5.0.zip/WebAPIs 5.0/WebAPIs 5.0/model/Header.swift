//
//	Header.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
import ObjectMapper

public struct Header : Decodable,Encodable{

	var accept : String!
	var acceptencoding : String!
	var cachecontrol : String!
	var cookie : String!
	var host : String!
	var postmantoken : String!
	var useragent : String!
	var xamzntraceid : String!
	var xforwardedport : String!
	var xforwardedproto : String!

	
	init(fromDictionary dictionary: [String:Any]){
		accept = dictionary["accept"] as? String
		acceptencoding = dictionary["accept-encoding"] as? String
		cachecontrol = dictionary["cache-control"] as? String
		cookie = dictionary["cookie"] as? String
		host = dictionary["host"] as? String
		postmantoken = dictionary["postman-token"] as? String
		useragent = dictionary["user-agent"] as? String
		xamzntraceid = dictionary["x-amzn-trace-id"] as? String
		xforwardedport = dictionary["x-forwarded-port"] as? String
		xforwardedproto = dictionary["x-forwarded-proto"] as? String
	}

	
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if accept != nil{
			dictionary["accept"] = accept
		}
		if acceptencoding != nil{
			dictionary["accept-encoding"] = acceptencoding
		}
		if cachecontrol != nil{
			dictionary["cache-control"] = cachecontrol
		}
		if cookie != nil{
			dictionary["cookie"] = cookie
		}
		if host != nil{
			dictionary["host"] = host
		}
		if postmantoken != nil{
			dictionary["postman-token"] = postmantoken
		}
		if useragent != nil{
			dictionary["user-agent"] = useragent
		}
		if xamzntraceid != nil{
			dictionary["x-amzn-trace-id"] = xamzntraceid
		}
		if xforwardedport != nil{
			dictionary["x-forwarded-port"] = xforwardedport
		}
		if xforwardedproto != nil{
			dictionary["x-forwarded-proto"] = xforwardedproto
		}
		return dictionary
	}
    
}
