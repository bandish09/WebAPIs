//
//  APIManager.swift
//  WebAPIs
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import ObjectMapper
import AlamofireObjectMapper



enum Formate {
    case rowjson
    case formData
}

let BaseUrl = "https://postman-echo.com/"


class APIManager {
    static let shared = APIManager()
    let NetworkSharedManager = NetworkReachability.sharedManager

    let getUrl: String = "\(BaseUrl)\("get?foo1=bar1&foo2=bar2")"
    let postUrl: String = "\(BaseUrl)\("post")"
    
    func getHeader() -> HTTPHeaders {
        var headerParam: HTTPHeaders = [:]
        headerParam["Authorization"] = "Bearer yourToken"
        headerParam["Accept"] = "application/json"
        return headerParam
    }

    
    func postMethod(param:[String:Any], paramFormate: Formate, successful:@escaping (RootClass)->Void, failure: (APIError)->Void){

//Note::  1. if encoding formate is 'JsonEncoding.defaul' then parameter is passed with Row json formate
//        2. if encoding formate is 'URLEncoding.default' then parameter is passed with form-data formate
        
        
        var encodingFormat: ParameterEncoding?
        if paramFormate == .rowjson{
            encodingFormat = JSONEncoding.default //JsonEncoding.defalt is formate so you will get param in 'data' key value.
        } else if paramFormate == .formData{
            encodingFormat = URLEncoding.default //URLEncoding.defalt is formate so you will get param in 'form' key value.
        }
        
//        Alamofire.request(postUrl, method: .post, parameters: param, encoding: encodingFormat!, headers: nil).responseString { (response: DataResponse<String>) in
//            print("response::: \(response)") //JsonEncoding.defalt is formate so you will get param in 'data' key value.
//        }

        
        Alamofire.request(postUrl, method: .post, parameters: param, encoding: encodingFormat!, headers: nil).responseObject { (response: DataResponse<RootClass>) in
            if response.result.isSuccess{
                if let baseResponse = response.result.value{
                    successful(baseResponse)
                }else{
                    print("Failed::: postMethod")
                }
            }else{
                print("Failed::: postMethod")
            }
        }
    }

    
    func getMethod(successful:@escaping (RootClass)->Void, failure: (APIError)->Void){
        
        /*Alamofire.request(getUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON { (response) in
            if response.result.isSuccess{
                if let json = response.result.value{
                    let objRootClass = RootClass(fromDictionary: json as! [String : Any])
                    successful(objRootClass)
                }else{
                    print("Failed::: getMethod")
                }
            }else{
                print("Failed::: getMethod")
            }
        }*/
        
        /*Alamofire.request(getUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseObject { (response: DataResponse<RootClass>) in
            if response.result.isSuccess{
                if let baseResponse = response.result.value{
                    successful(baseResponse)
                }else{
                    print("Failed::: getMethod")
                }
            }else{
                print("Failed::: getMethod")
            }
            
        }*/
    
    }

    
    func downlodingImage(imageBlock:@escaping (UIImage)->Void){
        
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,
            .userDomainMask, true)[0]
            let documentsURL = URL(fileURLWithPath: documentsPath, isDirectory: true)
            let fileURL = documentsURL.appendingPathComponent("image.png")
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }

        Alamofire.download("https://httpbin.org/image/png", to:
        destination).downloadProgress { progress in
                print("Download Progress: \(progress.fractionCompleted)")
        }.responseData { response in
            debugPrint(response)
            if let data = response.result.value {
                if let image = UIImage(data: data){
                    imageBlock(image)
                } else{
                    print("image not found")
                }
                
            } else {
                print("Data was invalid")
            }
        }
    }
    
    func uploadingImage(){
        let data = Data("data".utf8)

        //Uploading file/image
        Alamofire.upload(data, to: "Your server link").downloadProgress(closure: { (Progress) in
            print("progress:: \(Progress.fractionCompleted)")
        }).responseString { (response: DataResponse<String>) in
            print("your response is \(response.result.value)")
        }
        
        //Uploading file/image with multipartform data
        Alamofire.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(Data("file".utf8), withName: "file", fileName: "file.png", mimeType: "application/octet-stream")
        }, to: "Your server Address",
           method: .put,
           headers: self.getHeader(),
           encodingCompletion: { encodingResult in
            
            switch encodingResult {
            case .success(let upload, _, _):
                print("upload successfully")
            case .failure(let encodingError):
                print("error:\(encodingError)")
                
            }
            
            })
    }
        
}
