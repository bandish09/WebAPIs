//
//  ViewController.swift
//  WebAPIs
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Post Method with Row Json
        //self.callPostAPI()
        
        //Get Method
        self.callGetAPI()
        
        //Image Downloading
//        callImageDownloading()
        
        //File/image Uploading
//        APIManager.shared.uploadingImage() //currently we dont have any server detail to upload data
    }

    func callImageDownloading(){
        APIManager.shared.downlodingImage { (img: UIImage) in
            print("img:::: \(img)")
            self.imgView.image = img
        }
    }
    
    func callPostAPI(){
        APIManager.shared.postMethod(param: ["foo1":"bar1", "foo2":"bar2"], paramFormate: Formate.formData, successful: { (objRootClass: RootClass) in
            print("POST URL is ::: \(String(describing: objRootClass.url))")
            let defaults = UserDefaults.standard
            do {
                //save object
                let data = try NSKeyedArchiver.archivedData(withRootObject: objRootClass, requiringSecureCoding: false)
                defaults.set(data, forKey: "root")
                defaults.synchronize()
                
                //retrive object
                if let tempObject = defaults.value(forKey: "root"){
                    let objRoot = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(tempObject as! Data)  as? RootClass
                    print("objroot::: \(String(describing: objRoot?.url))")
                }
            } catch {
                fatalError("Can't encode data: \(error)")
            }
            }) { (err: APIError) in
            print("error::: \(err.localizedDescription)")
        }
    }
    
    func callGetAPI(){
        APIManager.shared.getMethod(successful: { (objRootClass: RootClass) in
            print("GET URL is:::: \(String(describing: objRootClass.url))")
//            print("jsong is :: \(objRootClass.toDictionary())")
        }) { (err: APIError) in
            print("error::: \(err.localizedDescription)")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
}

