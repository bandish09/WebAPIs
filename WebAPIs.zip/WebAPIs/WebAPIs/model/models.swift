//
//  post.swift
//  WebAPIs
//
//  Created by Bandish on 09/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import ObjectMapper


extension NSCoder {
    func decodeString(forKey key: String) -> String {
        if let str = self.decodeObject(forKey: key) as? String {
            return str
        }
        return ""
    }
}

// Error Code Type
enum ErrorType: Error {
    case Service
    case Network
    case None
}


class APIError: NSObject {
    var errorType: ErrorType = .None
    var error: Error?
    
    var localizedDescription: String {
        var str = ""
        switch self.errorType {
        case .Service:
            str = "Server Error!!"
            break
            
        case .Network:
            str = "Network not available."
            break
            
        default:
            str = "Server Error!!"
            break
        }
        return str
    }
}


class post: NSObject, Mappable, NSCoding {
    var userId = 0
    var id = 0
    var title = ""
    var body  = ""
    
    
    override init() {
    }
    
    required init?(map: Map){
    }
    
    func mapping(map: Map) {
        userId <- map["userId"]
        id <- map["id"]
        title <- map["title"]
        body <- map["body"]
        
    }
    
    func encode(with aCoder: NSCoder)
    {
        aCoder.encode(userId, forKey: "userId")
        aCoder.encode(id, forKey: "id")
        aCoder.encode(title, forKey: "title")
        aCoder.encode(body, forKey: "body")
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        userId = aDecoder.decodeInteger(forKey: "userId")
        id = aDecoder.decodeInteger(forKey: "id")
        title = aDecoder.decodeString(forKey: "title")
        body = aDecoder.decodeString(forKey: "body")
    }
}



