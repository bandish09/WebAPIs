//
//	Header.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
import ObjectMapper

class Header : NSObject, NSCoding, Mappable{

	var accept : String!
	var acceptencoding : String!
	var cachecontrol : String!
	var cookie : String!
	var host : String!
	var postmantoken : String!
	var useragent : String!
	var xamzntraceid : String!
	var xforwardedport : String!
	var xforwardedproto : String!


    override init() {
    }
    
    required init?(map: Map){
    }
    
    func mapping(map: Map) {
        accept <- map["accept"]
        acceptencoding <- map["acceptencoding"]
        cachecontrol <- map["cachecontrol"]
        cookie <- map["cookie"]
        host <- map["host"]
        postmantoken <- map["postmantoken"]
        useragent <- map["useragent"]
        xamzntraceid <- map["xamzntraceid"]
        xforwardedport <- map["xforwardedport"]
        xforwardedproto <- map["xforwardedproto"]
        
    }

    
	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		accept = dictionary["accept"] as? String
		acceptencoding = dictionary["accept-encoding"] as? String
		cachecontrol = dictionary["cache-control"] as? String
		cookie = dictionary["cookie"] as? String
		host = dictionary["host"] as? String
		postmantoken = dictionary["postman-token"] as? String
		useragent = dictionary["user-agent"] as? String
		xamzntraceid = dictionary["x-amzn-trace-id"] as? String
		xforwardedport = dictionary["x-forwarded-port"] as? String
		xforwardedproto = dictionary["x-forwarded-proto"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if accept != nil{
			dictionary["accept"] = accept
		}
		if acceptencoding != nil{
			dictionary["accept-encoding"] = acceptencoding
		}
		if cachecontrol != nil{
			dictionary["cache-control"] = cachecontrol
		}
		if cookie != nil{
			dictionary["cookie"] = cookie
		}
		if host != nil{
			dictionary["host"] = host
		}
		if postmantoken != nil{
			dictionary["postman-token"] = postmantoken
		}
		if useragent != nil{
			dictionary["user-agent"] = useragent
		}
		if xamzntraceid != nil{
			dictionary["x-amzn-trace-id"] = xamzntraceid
		}
		if xforwardedport != nil{
			dictionary["x-forwarded-port"] = xforwardedport
		}
		if xforwardedproto != nil{
			dictionary["x-forwarded-proto"] = xforwardedproto
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         accept = aDecoder.decodeObject(forKey: "accept") as? String
         acceptencoding = aDecoder.decodeObject(forKey: "accept-encoding") as? String
         cachecontrol = aDecoder.decodeObject(forKey: "cache-control") as? String
         cookie = aDecoder.decodeObject(forKey: "cookie") as? String
         host = aDecoder.decodeObject(forKey: "host") as? String
         postmantoken = aDecoder.decodeObject(forKey: "postman-token") as? String
         useragent = aDecoder.decodeObject(forKey: "user-agent") as? String
         xamzntraceid = aDecoder.decodeObject(forKey: "x-amzn-trace-id") as? String
         xforwardedport = aDecoder.decodeObject(forKey: "x-forwarded-port") as? String
         xforwardedproto = aDecoder.decodeObject(forKey: "x-forwarded-proto") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if accept != nil{
			aCoder.encode(accept, forKey: "accept")
		}
		if acceptencoding != nil{
			aCoder.encode(acceptencoding, forKey: "accept-encoding")
		}
		if cachecontrol != nil{
			aCoder.encode(cachecontrol, forKey: "cache-control")
		}
		if cookie != nil{
			aCoder.encode(cookie, forKey: "cookie")
		}
		if host != nil{
			aCoder.encode(host, forKey: "host")
		}
		if postmantoken != nil{
			aCoder.encode(postmantoken, forKey: "postman-token")
		}
		if useragent != nil{
			aCoder.encode(useragent, forKey: "user-agent")
		}
		if xamzntraceid != nil{
			aCoder.encode(xamzntraceid, forKey: "x-amzn-trace-id")
		}
		if xforwardedport != nil{
			aCoder.encode(xforwardedport, forKey: "x-forwarded-port")
		}
		if xforwardedproto != nil{
			aCoder.encode(xforwardedproto, forKey: "x-forwarded-proto")
		}

	}

}
