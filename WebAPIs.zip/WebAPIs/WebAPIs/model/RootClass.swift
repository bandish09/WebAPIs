//
//	RootClass.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
import AlamofireObjectMapper
import ObjectMapper

class RootClass : NSObject, NSCoding, Mappable{

	var args : Arg!
	var headers : Header!
	var url : String!

    override init() {
    }
    
    required init?(map: Map){
    }
    
    func mapping(map: Map) {
        args <- map["args"]
        headers <- map["headers"]
        url <- map["url"]
        
    }

	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		if let argsData = dictionary["args"] as? [String:Any]{
			args = Arg(fromDictionary: argsData)
		}
		if let headersData = dictionary["headers"] as? [String:Any]{
			headers = Header(fromDictionary: headersData)
		}
		url = dictionary["url"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if args != nil{
			dictionary["args"] = args.toDictionary()
		}
		if headers != nil{
			dictionary["headers"] = headers.toDictionary()
		}
		if url != nil{
			dictionary["url"] = url
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         args = aDecoder.decodeObject(forKey: "args") as? Arg
         headers = aDecoder.decodeObject(forKey: "headers") as? Header
         url = aDecoder.decodeObject(forKey: "url") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if args != nil{
			aCoder.encode(args, forKey: "args")
		}
		if headers != nil{
			aCoder.encode(headers, forKey: "headers")
		}
		if url != nil{
			aCoder.encode(url, forKey: "url")
		}

	}

}
