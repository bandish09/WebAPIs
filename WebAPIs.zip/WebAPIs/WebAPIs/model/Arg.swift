//
//	Arg.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
import ObjectMapper

class Arg : NSObject, NSCoding, Mappable{

	var foo1 : String!
	var foo2 : String!

    
    override init(){
        
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        foo1 <- map["foo1"]
        foo2 <- map["foo2"]
    }

	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		foo1 = dictionary["foo1"] as? String
		foo2 = dictionary["foo2"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if foo1 != nil{
			dictionary["foo1"] = foo1
		}
		if foo2 != nil{
			dictionary["foo2"] = foo2
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         foo1 = aDecoder.decodeObject(forKey: "foo1") as? String
         foo2 = aDecoder.decodeObject(forKey: "foo2") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if foo1 != nil{
			aCoder.encode(foo1, forKey: "foo1")
		}
		if foo2 != nil{
			aCoder.encode(foo2, forKey: "foo2")
		}

	}

}
